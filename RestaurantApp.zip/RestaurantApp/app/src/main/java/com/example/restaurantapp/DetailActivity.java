package com.example.restaurantapp;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

public class DetailActivity extends AppCompatActivity {
    private Restaurant mRestaurant;
    private TextView restaurantName, restaurantLocation, restaurantPrice, restaurantHours, restaurantCuisineDet, restaurantTelp, reviewCategory;
    private ImageView restaurantPicDet;
    private RatingBar ratingBar;
    private TextView reviewerName, reviewTitle, reviewDesc, ratingNumber;
    private Review review;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        //Attributes for restaurant
        restaurantName = findViewById(R.id.restaurantNameList);
        restaurantCuisineDet = findViewById(R.id.restaurantCuisineDet);
        restaurantLocation = findViewById(R.id.restaurantLocationList);
        ratingBar = findViewById(R.id.ratingBar);
        restaurantPrice = findViewById(R.id.restaurantPrice);
        restaurantHours = findViewById(R.id.restaurantHours);
        restaurantPicDet = findViewById(R.id.restaurantPicList);
        restaurantTelp = findViewById(R.id.restaurantTelp);

        //Attributes for review
        reviewCategory = findViewById(R.id.reviewCategory);
        reviewTitle = findViewById(R.id.reviewTitle);
        reviewDesc = findViewById(R.id.reviewDesc);
        ratingNumber = findViewById(R.id.ratingNumber);
        reviewerName = findViewById(R.id.reviewerName);

        Intent intent = getIntent();
        int position = intent.getIntExtra(MainActivity.MESSAGE, 0);

        //Setting each restaurant's attributes
        mRestaurant = Restaurant.getRestaurants().get(position);
        restaurantName.setText(mRestaurant.getName());
        restaurantLocation.setText(mRestaurant.getLocation());
        ratingBar.setRating(mRestaurant.getRating());
        restaurantPrice.setText(mRestaurant.getPrice());
        restaurantHours.setText(mRestaurant.getHours());
        restaurantCuisineDet.setText(mRestaurant.getCuisine());
        restaurantTelp.setText(mRestaurant.getTelp());

        //getting the image for each restaurant
        int picture = getResources().getIdentifier("pic_" + mRestaurant.getPicture(), "drawable", "com.example.restaurantapp");
        restaurantPicDet.setImageResource(picture);

        //set the description for the rating, based on the rating scores
        if (mRestaurant.getRating() >= 0 && mRestaurant.getRating() <= 2.5){
            reviewCategory.setText("Bad");
        } else if (mRestaurant.getRating() >= 2.6 && mRestaurant.getRating() <= 3.5){
            reviewCategory.setText("Average");
        } else if (mRestaurant.getRating() >= 3.6 && mRestaurant.getRating() <= 4.5){
            reviewCategory.setText("Good");
        } else if (mRestaurant.getRating() >= 4.6 && mRestaurant.getRating() <= 5.0){
            reviewCategory.setText("Excellent");
        }

        //getting review attributes
        review = Review.getReviews().get(position);
        reviewerName.setText(review.getReviewName());
        reviewTitle.setText(review.getReviewTitle());
        reviewDesc.setText(review.getReviewDesc());
        ratingNumber.setText(Float.toString(mRestaurant.getRating()));
    }
}


