package com.example.restaurantapp;

import java.util.ArrayList;

public class Restaurant {
    private String name;
    private String location;
    private float rating;
    private String hours;
    private String price;
    private String cuisine;
    private String telp;
    private int picture;

    public String getCuisine() {
        return cuisine;
    }

    public void setCuisine(String cuisine) {
        this.cuisine = cuisine;
    }

    public String getTelp() {
        return telp;
    }

    public void setTelp(String telp) {
        this.telp = telp;
    }

    public int getPicture() {
        return picture;
    }

    public void setPicture(int picture) {
        this.picture = picture;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public float getRating() {
        return rating;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }

    public String getHours() {
        return hours;
    }

    public void setHours(String hours) {
        this.hours = hours;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public Restaurant(String name, String location, float rating, String hours, String price, int picture, String cuisine, String telp){
        this.name = name;
        this.location = location;
        this.rating = rating;
        this.hours = hours;
        this.price = price;
        this.picture = picture;
        this.cuisine = cuisine;
        this.telp = telp;
    }

    public static ArrayList<Restaurant> getRestaurants(){
        ArrayList<Restaurant> restaurants = new ArrayList<>();
        restaurants.add(new Restaurant("Hao Chi", "Kingsford", 4.0f, "Open at 11am - 3pm", "$40 for two people",1, "Chinese","02 5550 2278"));
        restaurants.add(new Restaurant("Uncle's Hot Chicken","Kingsford",5.0f, "Open at 11am - 8pm","$30 for two people",2, "American","02 5550 5619"));
        restaurants.add(new Restaurant("Wrap It Up!", "Randwick",3.5f, "Open at 10am - 1pm", "$25 for two people",3, "Mexican", "02 5550 4692"));
        restaurants.add(new Restaurant("The Cookhouse","Randwick",4.5f, "Open at 12pm - 10.30pm","$50 for two people",4,"Western", "02 5550 8084"));
        restaurants.add(new Restaurant("Steakhouse","Surry Hills", 4.0f, "Open at 12pm - 11pm", "$55 for two people",5, "Western","02 5550 3974"));
        restaurants.add(new Restaurant("Let's Eat Thai", "Surry Hills", 3.5f, "Open at 10am - 5pm", "$40 for two people",6, "Thai", "02 5550 2736"));
        restaurants.add(new Restaurant("Hugo's", "Chippendale",4.5f,"Open at 10am - 5pm","$50 for two people",7, "Mexican", "02 5550 7368"));
        restaurants.add(new Restaurant("Alberto's Lounge","Chippendale",3.5f, "Open at 10am - 6pm","$30 for two people",8, "American", "02 5550 8348"));
        restaurants.add(new Restaurant("Yello","Paddington",4.0f,"Open at 10am - 6pm","$40 for two people",9, "Vegetarian", "02 5550 8544"));
        restaurants.add(new Restaurant("Spicy Alley","Paddington",5.0f,"Open at 10am - 7pm","$55 for two people",10, "Malay/Indo", "02 5550 6593"));
        return restaurants;
    }

}
