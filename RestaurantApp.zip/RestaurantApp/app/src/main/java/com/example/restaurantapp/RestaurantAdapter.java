package com.example.restaurantapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RestaurantAdapter extends RecyclerView.Adapter<RestaurantAdapter.RestaurantViewHolder> {

    private ArrayList<Restaurant> mRestaurants;
    private RecyclerViewClickListener mListener;

    public RestaurantAdapter(ArrayList<Restaurant> restaurants, RecyclerViewClickListener listener) {
        mRestaurants = restaurants;
        mListener = listener;
    }

    public interface RecyclerViewClickListener {
        void onClick(View view, int position);
    }

    public static class RestaurantViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView restaurantNameList, restaurantLocationList,restaurantCuisineList;
        public RatingBar ratingBarList;
        private RecyclerViewClickListener mListener;

        public RestaurantViewHolder(View v, RecyclerViewClickListener listener) {

            super(v);
            mListener = listener;
            v.setOnClickListener(this);
            restaurantNameList = v.findViewById(R.id.restaurantNameList);
            restaurantLocationList = v.findViewById(R.id.restaurantLocationList);
            ratingBarList = v.findViewById(R.id.ratingBarList);
            restaurantCuisineList = v.findViewById(R.id.restaurantCuisineList);

        }

        @Override
        public void onClick(View view) {
            mListener.onClick(view, getAdapterPosition());
        }
    }

    @Override
    public RestaurantAdapter.RestaurantViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.restaurant_list_row, parent, false);
        return new RestaurantViewHolder(v, mListener);
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(RestaurantViewHolder holder, int position) {
        //setting the restaurant's attributes that will be displayed on the list
        Restaurant restaurant = mRestaurants.get(position);
        holder.restaurantNameList.setText(restaurant.getName());
        holder.restaurantLocationList.setText(restaurant.getLocation());
        holder.ratingBarList.setRating(restaurant.getRating());
        holder.restaurantCuisineList.setText(restaurant.getCuisine());
    }

    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return mRestaurants.size();
    }

}
