package com.example.restaurantapp;

import java.util.ArrayList;

public class Review {
    private String reviewName;
    private String reviewTitle;
    private String reviewDesc;

    public String getReviewName() {
        return reviewName;
    }

    public void setReviewName(String reviewName) {
        this.reviewName = reviewName;
    }

    public String getReviewTitle() {
        return reviewTitle;
    }

    public void setReviewTitle(String reviewTitle) {
        this.reviewTitle = reviewTitle;
    }

    public String getReviewDesc() {
        return reviewDesc;
    }

    public void setReviewDesc(String reviewDesc) {
        this.reviewDesc = reviewDesc;
    }

    public Review(String reviewName, String reviewTitle, String reviewDesc){
        this.reviewName = reviewName;
        this.reviewTitle = reviewTitle;
        this.reviewDesc = reviewDesc;
    }

    public static ArrayList<Review> getReviews(){
        ArrayList<Review> reviews = new ArrayList<>();
        reviews.add(new Review("Anne","The best chicken rice in town!","I ordered their chicken rice meal package and it was so good! Definitely will come back!"));
        reviews.add(new Review ("Mark", "The grilled chicken is amazing!", "The chicken thigh is a must order! It was very yummy. The satay chicken, however, had a bit too much “grilled”- ness for my liking. The curry was also very enjoyable and not spicy at all."));
        reviews.add(new Review ("Simon", "Nice taste wrap", "Ordered a wrap combo. The price is moderate and taste okay, the portion is small. Greater you want to have a quick lunch"));
        reviews.add(new Review ("Dan", "Great Aussie pub", "The schnitzel in particular had a nice breading, was cooked perfectly and was served with salad and chips. These meals were all 10$ apiece - so great value."));
        reviews.add(new Review("Angus", "Great steaks!","Hidden away off the street. Good ambiance. Great steaks. Good service. Not too loud. Highly recommended"));
        reviews.add(new Review("David","Tasty Thai food!","Nice fresh and tasty Thai Beef Salad. Very spicy. Full of fresh ingredients. Very nice spring rolls also. Water on the table. The restaurant is halal, no alcohol allowed."));
        reviews.add(new Review("Marianna","The best burrito!", "Nice Breakfast burrito. Had Chorizo one, egg, salsa. Ordered via app and it was ready for pickup as soon as I got there. Tasty and hot, nice friendly service"));
        reviews.add(new Review("Kevin","Nice place", "Delicious hearty food. Friendly service. Very cosy restaurant...you HAVE to book and you get slotted into seating sessions. Portions not huge, but food was tasty and cooked well."));
        reviews.add(new Review("Michael","Interesting veggie restaurant","Whilst I'm not a vegetarian I do like vegetarian meals. The food here is exceptionally good but portion size is very small for veggie meals and quite expensive due to the size of the meals."));
        reviews.add(new Review("Sally","Asian Delight","Craving for Thai, Indonesian, Malaysian, Singaporean, Chinese food? Everything is right here. The place can be jam-packed because Sydney-siders cram to this alley for dinner. Is it worth it? Yes. This is a must visit place."));
        return reviews;
    }


}
