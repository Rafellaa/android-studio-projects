This project is about creating an MVP of a restaurant suggestion application of places around Sydney NSW.
Inspiration of this project is obtained from Zomato restaurant rating app.
The project is written in Java, using Android Studio as the IDE.