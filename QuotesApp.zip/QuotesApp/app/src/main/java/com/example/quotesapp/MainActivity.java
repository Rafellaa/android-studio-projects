package com.example.quotesapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
    private Button randomButton;
    private TextView randomText;
    private ImageView shareImage;
    private String TAG;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        randomButton = findViewById(R.id.randomButton);
        randomText = findViewById(R.id.randomText);
        shareImage = findViewById(R.id.shareImage);

            //Create retrofit instance and parse the retrieved JSON using the GSON deserializer
            Retrofit retrofit = new Retrofit.Builder().baseUrl("https://api.chucknorris.io")
                    .addConverterFactory(GsonConverterFactory.create()).build();

            //Get service and call object for the request
            ChuckNorrisInterface anInterface = retrofit.create(ChuckNorrisInterface.class);
            Call<Joke> jokeCall = anInterface.getRandomJoke();

            //Set what will happen when a user clicks on the button
            randomButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    jokeCall.clone().enqueue(new Callback<Joke>() {
                        @Override
                        public void onResponse(Call<Joke> call, Response<Joke> response) {
                            Log.d(TAG, "onResponse: SUCCESS");
                            if(response.body() != null) {
                                String joke = response.body().getValue();
                                randomText.setText(joke);
                            } else {
                                //to de-bug the code and see whether response is working or not
                                randomText.setText("response is null");
                            }
                        }

                        @Override
                        public void onFailure(Call<Joke> call, Throwable t) {
                            Log.d(TAG, "onFailure: FAILURE");
                        }
                    });
                }
            });

            //A feature to allow user to share the joke
            shareImage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String jokeString = randomText.getText().toString();
                        Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
                        sharingIntent.setType("text/plain");
                        sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Subject Here");
                        sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, jokeString);
                        startActivity(Intent.createChooser(sharingIntent, "Share text via"));
                }
            });
        }






    }

