package com.example.quotesapp;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Url;

public interface ChuckNorrisInterface {

    //Getting only 1 joke in dev category
    @GET("/jokes/random?category=dev")
    Call<Joke> getRandomJoke();


}
